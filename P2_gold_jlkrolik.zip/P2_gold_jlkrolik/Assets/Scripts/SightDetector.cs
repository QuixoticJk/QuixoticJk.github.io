using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SightDetector : MonoBehaviour
{
    PolygonCollider2D polygonCollider2D;
    public System.Action onSightDetected;
    public System.Action onSightUndetected;

    public string detectTag;
    void Start()
    {
        polygonCollider2D = GetComponent<PolygonCollider2D>();
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log(other.gameObject.tag + " entered");
        if (other.gameObject.tag != null)
        {
            if (other.gameObject.CompareTag(detectTag))
            {
                Debug.Log("its the player");
                if (onSightDetected != null)
                {
                    onSightDetected();
                }
            }
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        Debug.Log(other.gameObject.tag + " entered");
        if (other.gameObject.tag != null)
        {
            if (other.gameObject.CompareTag(detectTag))
            {
                Debug.Log("its the player");
                if (onSightUndetected != null)
                {
                    onSightUndetected();
                }
            }
        }
    }
}
