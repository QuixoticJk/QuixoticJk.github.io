using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject WinText;
    public GameObject LoseText;
    public GameObject RestartText;
    public bool win = false;
    public static GameController instance;
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        Screen.SetResolution(1920, 1080, false);
    }
    // Update is called once per frame
    void Update()
    {
        // on game over screen, hit space to reload scene
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        if (win && (Input.GetKeyDown("space")))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
    public void doWin()
    {
        WinText.SetActive(true);
        RestartText.SetActive(true);
        win = true;
    }
    public void doLose()
    {
        LoseText.SetActive(true);
        RestartText.SetActive(true);
        win = true;
    }
}
