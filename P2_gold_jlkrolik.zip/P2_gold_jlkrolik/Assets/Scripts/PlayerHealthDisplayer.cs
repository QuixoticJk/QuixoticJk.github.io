using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealthDisplayer : MonoBehaviour
{
    Text health_text_component;

    // Start is called before the first frame update
    void Start()
    {
        health_text_component = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        float playerHealth = GameObject.Find("Player").GetComponent<HasHealth>().GetHealth();
        health_text_component.text = "Hearts: " + playerHealth.ToString();
    }


}
