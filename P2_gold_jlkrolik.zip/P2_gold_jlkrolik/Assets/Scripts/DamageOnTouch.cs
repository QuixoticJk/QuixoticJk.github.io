using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageOnTouch : MonoBehaviour
{
    public float healthChangeOnCollision = -0.5f;

    private void OnCollisionEnter2D(Collision2D other)
    {
        DealDamage(other.gameObject);
    }

    private void OnCollisionStay2D(Collision2D other)
    {
        DealDamage(other.gameObject);
    }

    // call AlterHealth
    private void DealDamage(GameObject potential_player)
    {
        if (potential_player.tag == "Player")
        {
            potential_player.GetComponent<HasHealth>().AlterHealth(healthChangeOnCollision, gameObject);
        }
    }
}
