using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HasHealth : MonoBehaviour
{
    // public System.Action KO_callback;
    // public System.Action enterKnockback_callback;
    // public System.Action leaveKnockback_callback;

    // max health of entity
    public float maxHealth = 3.0f;
    // stores the current health value
    public float health = 3.0f;

    // hit stun duration
    public float HitStunDuration = 1.0f;
    // staggers calls to decrement health - enables "i-frames"
    public bool canTakeDamage = true;

    // sets true when grabbed by Wallmaster - only damage is dealt - no knockback
    // public bool isGrabbed = false;

    // enables player only functionality - mostly adjusting healthfull
    private bool isPlayer = false;

    // runs on start of scene or initialization
    public void Start()
    {
        if (this.gameObject.tag == "Player")
        {
            isPlayer = true;


        }
    }

    // normal health change - can be positive or negative
    public void AlterHealth(float delta, GameObject other)
    {
        // positive change
        if (delta > 0)
        {
            health += delta;
            if (health >= maxHealth)
            {
                health = maxHealth;

            }
        }
        // negative change
        else if (delta < 0)
        {
            // only start damage sequence if canTakeDamage
            if (canTakeDamage && !gameObject.GetComponent<ArrowKeyMovement>().attackCoolDown)
            {
                StartCoroutine(DamageProcess(delta, other));
            }
        }
    }

    // damage process, including any knockback calls and iframes
    IEnumerator DamageProcess(float delta, GameObject other)
    {
        canTakeDamage = false;
        health += delta;

        // if health drops to 0 or below, call KO_callback - custom System.Action
        if (health <= 0 && isPlayer)
        {
            gameObject.GetComponent<ArrowKeyMovement>().enabled = false;

            GameController.instance.doLose();

        }

        // call code to enter knockback state - custom System.Action
        //enterKnockback_callback();

        // apply hit stun
        // deal knockback and make sprite red
        Rigidbody2D rb = GetComponent<Rigidbody2D>();
        float knockbackangle = Mathf.Atan2(gameObject.transform.position.y - other.transform.position.y, gameObject.transform.position.x - other.transform.position.x) * 180 / Mathf.PI;
        int roundedAngle = (int)(Mathf.Round(knockbackangle / 90));
        knockbackangle = roundedAngle * 90 * Mathf.Deg2Rad;
        Vector3 knockbackDirection = new Vector3(Mathf.Cos(knockbackangle), Mathf.Sin(knockbackangle), 0.0f).normalized;
        rb.velocity = knockbackDirection * 20.0f;
        Debug.Log("one instance of knockback");

        // change color to indicate damage
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        Color OGColor = sprite.color;
        sprite.color = Color.red;

        // initial hit stun duration
        // remnant i-frames
        yield return StartCoroutine(hit_stun());
        yield return StartCoroutine(invinciblity(sprite, OGColor));
        // re-enable damage taking
        canTakeDamage = true;

    }

    // initial period of hit reaction - hit stun (no movement, invincible)
    IEnumerator hit_stun()
    {
        yield return new WaitForSeconds(HitStunDuration * 0.3f);

        // leaveKnockback_callback();
    }

    // last period of hit - i-frames (movement, invincible)
    IEnumerator invinciblity(SpriteRenderer sprite, Color color)
    {
        // yields for given time, then finally change sprite color back to normal
        yield return new WaitForSeconds(HitStunDuration * 0.7f);
        sprite.color = color;
    }

    // returns current entity health
    public float GetHealth()
    {
        return health;
    }
}