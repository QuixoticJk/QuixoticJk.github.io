using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWalk : MonoBehaviour
{
    Vector2 startPoint;
    public float speed = 5;
    public float distance = 6f;
    Vector2 direction = Vector2.right;
    // Update is called once per frame
    void Start()
    {
        startPoint = transform.position;
    }
    void Update()
    {
        if (Mathf.Abs(Vector2.Distance(startPoint, transform.position)) > distance)
        {
            transform.localScale = new Vector3(transform.localScale.x * -1, 1, 1);
            transform.position = new Vector2(startPoint.x + (direction.x * (distance - 0.1f)), transform.position.y);
            direction *= -1;
        }
        GetComponent<Rigidbody2D>().velocity = direction * speed;
    }
}
