using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    float timer = 0;
    public float maxTime = 1;
    public float coolDownTime = 4f;
    public float timeBetweenAttacks = 1f;
    public float rDistance = 6f;
    public bool canBeDestroyed = true;
    bool aim = true;
    Vector2 direction = Vector2.zero;
    LineRenderer laserLineRenderer;
    char senseState = 'G';
    public SpriteRenderer sensorSpriteRenderer;
    // Start is called before the first frame update
    void Start()
    {
        if (GetComponentInChildren<SightDetector>())
        {
            GetComponentInChildren<SightDetector>().onSightDetected += callDetected;
            GetComponentInChildren<SightDetector>().onSightUndetected += callUndetected;
            laserLineRenderer = GetComponent<LineRenderer>();
            Vector3[] initLaserPositions = new Vector3[2] { Vector3.zero, Vector3.zero };
            laserLineRenderer.SetPositions(initLaserPositions);
            laserLineRenderer.startWidth = 0.1f;
            laserLineRenderer.endWidth = 0.1f;
        }

    }

    // Update is called once per frame
    void Update()
    {
        if (senseState == 'G')
        {
            sensorSpriteRenderer.color = new Color(0, 1, 0, 0.1f);
            timer -= (Time.deltaTime / 2);

        }
        else if (senseState == 'Y')
        {
            sensorSpriteRenderer.color = new Color(1, 0.96f, 0.08f, 0.1f);
            timer += Time.deltaTime;
        }
        timer = Mathf.Clamp(timer, 0, maxTime);
        if (timer == maxTime)
        {
            timer = 0;
            StartCoroutine(coolOff());
            StartCoroutine(doAttackMode());
        }

        if (senseState == 'R')
        {
            sensorSpriteRenderer.color = new Color(1, 0, 0, 0.1f);
            laserLineRenderer.enabled = true;
            if (Vector2.Distance(transform.position, GameObject.Find("Player").transform.position) > rDistance)
            {
                StopCoroutine(coolOff());
                senseState = 'G';
            }
            if (aim)
            {
                direction = GameObject.Find("Player").transform.position - transform.position;
                ShootLaserFromTargetPosition(transform.position, direction, rDistance);
            }
            else
            {
                ShootLaserFromTargetPosition(transform.position, direction, rDistance);
            }

        }
        else
        {
            if (laserLineRenderer)
            {
                laserLineRenderer.enabled = false;
            }
        }

    }
    void callDetected()
    {
        if (senseState != 'R')
            senseState = 'Y';
    }
    void callUndetected()
    {
        if (senseState != 'R')
            senseState = 'G';
    }

    IEnumerator coolOff()
    {
        senseState = 'R';
        yield return new WaitForSeconds(coolDownTime);
        senseState = 'G';
    }
    IEnumerator doAttackMode()
    {
        while (senseState == 'R')
        {
            yield return new WaitForEndOfFrame();
            StartCoroutine(doAttack());
            yield return new WaitForSeconds(timeBetweenAttacks);
        }
    }
    void ShootLaserFromTargetPosition(Vector3 targetPosition, Vector3 direction, float length)
    {

        RaycastHit2D raycast2DHit = Physics2D.Raycast(transform.position, direction, length, LayerMask.GetMask("Player", "Ground"));
        Vector3 endPosition = targetPosition + (length * direction);

        if (raycast2DHit)
        {
            endPosition = raycast2DHit.point;
        }

        laserLineRenderer.SetPosition(0, targetPosition);
        laserLineRenderer.SetPosition(1, endPosition);
    }

    private void OnDestroy()
    {
        if (GetComponentInChildren<SightDetector>())
        {
            GetComponentInChildren<SightDetector>().onSightDetected -= callDetected;
            GetComponentInChildren<SightDetector>().onSightUndetected -= callUndetected;
        }

    }

    IEnumerator doAttack()
    {
        aim = false;
        yield return new WaitForSeconds(0.2f);
        laserLineRenderer.startColor = new Color(1, 0, 0, 0.6f);
        laserLineRenderer.endColor = new Color(1, 0, 0, 0.6f);
        RaycastHit2D raycast2DHit = Physics2D.Raycast(transform.position, direction, rDistance, LayerMask.GetMask("Player"));
        if (raycast2DHit)
        {
            GameObject.Find("Player").GetComponent<HasHealth>().AlterHealth(-1, gameObject);
        }
        yield return new WaitForSeconds(0.3f);
        aim = true;
        laserLineRenderer.startColor = new Color(1, 0, 1, 0.6f);
        laserLineRenderer.endColor = new Color(1, 0, 1, 0.6f);


    }
}
