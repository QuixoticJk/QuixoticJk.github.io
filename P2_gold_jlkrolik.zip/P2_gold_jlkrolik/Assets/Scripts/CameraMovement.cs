using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    // camera will follow this object
    public Transform Target;
    // offset between camera and target
    // change this value to get desired smoothness
    public float SmoothTime = 0.3f;
    public float minX, minY, maxX, maxY;
    // Desired duration of the shake effect
    private float shakeDuration = 0f;

    // A measure of magnitude for the shake. Tweak based on your preference
    private float shakeMagnitude = 0.7f;

    // A measure of how quickly the shake effect should evaporate
    private float dampingSpeed = 1.0f;

    // The initial position of the GameObject
    Vector3 initialPosition;
    Vector3 expectedPosition;

    // This value will change at the runtime depending on target movement. Initialize with zero vector.
    private Vector3 velocity = Vector3.zero;
    void LateUpdate()
    {
        // update position
        Vector3 targetPosition = Target.position;
        expectedPosition = Vector3.SmoothDamp(transform.position, targetPosition, ref velocity, SmoothTime);
        expectedPosition = new Vector3(Mathf.Clamp(expectedPosition.x, minX, maxX), Mathf.Clamp(expectedPosition.y, minY, maxY), -10);

        if (shakeDuration > 0)
        {
            transform.localPosition = initialPosition + Random.insideUnitSphere * shakeMagnitude;

            shakeDuration -= Time.deltaTime * dampingSpeed;
        }
        else
        {
            shakeDuration = 0f;
            transform.localPosition = expectedPosition;
        }
    }
    public void TriggerShake(float duration, float mag = 0.7f)
    {
        initialPosition = transform.position;
        shakeMagnitude = mag;
        shakeDuration = duration;
    }
}

