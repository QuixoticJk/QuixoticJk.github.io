using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowKeyMovement : MonoBehaviour
{
    float stamina = 100f;
    float maxStamina = 100f;
    Transform reticle;
    Rigidbody2D rb;
    bool isGrounded = false;
    bool isTouchingWall = false;
    bool climbing = false;
    bool wallJump = false;
    bool upAndOver = false;
    bool jumping = false;
    Vector2 touchDir = Vector2.zero;
    Vector2 movement;
    int groundLayer;
    Transform playerGroundLocation;
    BoxCollider2D boxCollider2D;
    float originalGravity = 3;
    SpriteRenderer spriteRenderer;
    public Sprite[] walkSprites = new Sprite[4];
    public Sprite[] climbSprites = new Sprite[4];
    Sprite[] currSprites = new Sprite[4];
    Transform sensor;
    GameObject targetedObject;
    Color defaultColor = Color.white;
    int count = 0;
    bool animateRunning = false;
    bool dashing = false;
    bool canDash = true;
    bool dashCooldown = false;
    public bool attackCoolDown = false;
    bool holding = false;

    public float climbMultiplyer = 5;
    public float StaminaDecreasePerFrame = 10.0f;
    public float homingAttackSpeed = 1.5f;
    public float homingAttackDivider = 8;
    public float dashTime = 0.5f;
    public float dashSpeed = 5;
    public float wallSlideSpeed = 5;
    public float playerSpeed = 5;
    public float jumpForce = 1;
    public float climbSpeed = 100;
    public float wallJumpForce = 8;


    // Start is called before the first frame update
    void Start()
    {
        reticle = transform.Find("reticle");
        sensor = transform.Find("sensor");
        spriteRenderer = GetComponent<SpriteRenderer>();
        boxCollider2D = GetComponent<BoxCollider2D>();
        playerGroundLocation = transform.Find("groundPosition");
        rb = GetComponent<Rigidbody2D>();
        groundLayer = LayerMask.GetMask("Ground");
        StartCoroutine(manageSprites());
        StartCoroutine(animateStamina());
    }
    IEnumerator doDash(Vector2 direction)
    {
        bool cutVert = false;
        if (isGrounded && direction.y < 0)
            direction.y = 0;
        rb.gravityScale = 0;
        dashing = true;
        if (jumping)
        {
            cutVert = true;
        }
        canDash = false;
        spriteRenderer.color = new Color(0.0f, 1, 1, 1);
        defaultColor = spriteRenderer.color;
        rb.velocity = direction.normalized * dashSpeed;
        yield return new WaitForSeconds(dashTime);
        dashing = false;
        rb.gravityScale = originalGravity;
        spriteRenderer.color = new Color(0.4f, 1, 1, 1);
        defaultColor = spriteRenderer.color;
        if (cutVert || !jumping)
        {
            rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y / 3);
        }
        dashCooldown = true;
        yield return new WaitForSeconds(0.15f);
        dashCooldown = false;
        if (isGrounded)
        {
            spriteRenderer.color = new Color(1, 1, 1, 1);
            defaultColor = spriteRenderer.color;
            canDash = true;
        }


    }
    IEnumerator doAttack()
    {
        if (targetedObject != null)
        {
            gameObject.layer = LayerMask.NameToLayer("Attacking");
            Camera.main.gameObject.GetComponent<CameraMovement>().TriggerShake(0.1f, 0.3f);
            GameObject objectToKill = targetedObject;
            bool cutVert = false;
            rb.gravityScale = 0;
            dashing = true;
            if (jumping)
            {
                cutVert = true;
            }

            //gameObject.layer = 9;
            canDash = false;
            spriteRenderer.color = new Color(0.0f, 1, 1, 1);
            defaultColor = spriteRenderer.color;
            rb.velocity = (targetedObject.transform.position - transform.position).normalized * dashSpeed * homingAttackSpeed;
            Debug.Log((targetedObject.transform.position - transform.position) * dashSpeed * homingAttackSpeed);
            Debug.Log((targetedObject.transform.position - transform.position).magnitude / homingAttackDivider);
            attackCoolDown = true;
            yield return new WaitForSeconds(dashTime * ((targetedObject.transform.position - transform.position).magnitude / homingAttackDivider));
            dashing = false;
            //gameObject.layer = 3;
            if (objectToKill)
            {
                if (objectToKill.GetComponent<Enemy>())
                {
                    if (objectToKill.GetComponent<Enemy>().canBeDestroyed)
                    {
                        Destroy(objectToKill.gameObject);
                        objectToKill = null;
                    }
                }
            }
            rb.gravityScale = originalGravity;
            spriteRenderer.color = new Color(1, 1, 1, 1);
            defaultColor = spriteRenderer.color;
            if (cutVert || !jumping)
            {
                rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y / 8);
            }
            canDash = true;
            yield return new WaitForSeconds(0.15f);
            attackCoolDown = false;
            gameObject.layer = LayerMask.NameToLayer("Player");



        }
    }
    // IEnumerator MoveObjectOverTime(Vector2 initial_position, Vector2 dest_position, float duration_sec)
    // {
    //     float initial_time = Time.time;
    //     float progress = (Time.time - initial_time) / duration_sec;

    //     // move fraction to dest_position based on progressed time
    //     while (progress < 1.0f)
    //     {
    //         // update progress and translate position proportionally to progress fraction
    //         progress = (Time.time - initial_time) / duration_sec;
    //         Vector3 new_position = Vector3.Lerp(initial_position, dest_position, progress);

    //         // update camera position
    //         gameObject.GetComponent<Transform>().position = new_position;

    //         // yield so other functions run before next iteration of while loop
    //         yield return null;
    //     }

    //     // final change to position
    //     gameObject.GetComponent<Transform>().position = dest_position;
    // }


    void GroundCheck()
    {
        RaycastHit2D hit;
        float distance = 0.1f;

        hit = Physics2D.BoxCast(playerGroundLocation.position, new Vector2(0.75f, 0.05f), 0f, Vector2.down, distance, groundLayer);

        if (hit.collider != null)
        {
            isGrounded = true;
            if (!dashCooldown)
            {
                spriteRenderer.color = new Color(1, 1, 1, 1);
                defaultColor = spriteRenderer.color;
                canDash = true;

            }
        }
        else
        {
            isGrounded = false;
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!dashing)
        {
            rb.gravityScale = originalGravity;
            if (!wallJump && !upAndOver)
            {
                float horizontal_input = Input.GetAxisRaw("Horizontal");
                rb.velocity = new Vector2(horizontal_input * playerSpeed * Time.fixedDeltaTime, rb.velocity.y);

                GroundCheck();
                // No horizontal movement, stop velocity if on the ground.
                if (horizontal_input == 0 && isGrounded == true)
                {

                    rb.velocity = new Vector2(0, rb.velocity.y);
                }
                if (climbing)
                {
                    RaycastHit2D hit = Physics2D.BoxCast(transform.position, boxCollider2D.size, 0f, touchDir, 0.1f, groundLayer);
                    if (hit)
                    {
                        float vertical_input = Input.GetAxisRaw("Vertical");
                        rb.velocity = new Vector2(0, vertical_input * climbSpeed * Time.fixedDeltaTime);
                        rb.gravityScale = 0;
                    }
                    else
                    {
                        hit = Physics2D.BoxCast(new Vector2(transform.position.x, transform.position.y + 0.2f), boxCollider2D.size, 0f, touchDir, 0.1f, groundLayer);
                        if (hit)
                        {
                            float vertical_input = Input.GetAxisRaw("Vertical");
                            if (vertical_input > 0)
                            {
                                rb.velocity = new Vector2(0, vertical_input * climbSpeed * Time.fixedDeltaTime);
                            }
                            else
                            {
                                rb.velocity = new Vector2(0, 0);

                            }
                            rb.gravityScale = 0;
                        }
                        else
                        {
                            float vertical_input = Input.GetAxisRaw("Vertical");
                            rb.velocity = new Vector2(0, vertical_input * climbSpeed * 2 * Time.fixedDeltaTime);
                            rb.gravityScale = 0;
                            StartCoroutine(doUpAndOver());
                        }
                    }

                }
                else
                {
                    Vector2 moveDirection = new Vector2(rb.velocity.x * Time.fixedDeltaTime, 0);
                    if (moveDirection.normalized == Vector2.left)
                    {
                        spriteRenderer.flipX = false;
                    }
                    else if (moveDirection.normalized == Vector2.right)
                    {
                        spriteRenderer.flipX = true;
                    }

                    // Get bounds of Collider
                    var topRight = new Vector2(boxCollider2D.bounds.max.x, boxCollider2D.bounds.max.y);
                    var bottomLeft = new Vector2(boxCollider2D.bounds.min.x, boxCollider2D.bounds.min.y);

                    // Move collider in direction that we are moving
                    topRight += moveDirection;
                    bottomLeft += moveDirection;
                    Collider2D collider2D1 = Physics2D.OverlapArea(bottomLeft, topRight, groundLayer);
                    topRight -= (moveDirection * 2);
                    bottomLeft -= (moveDirection * 2);
                    Collider2D collider2D2 = Physics2D.OverlapArea(bottomLeft, topRight, groundLayer);
                    // Check if the body's current velocity will result in a collision
                    if (collider2D1)
                    {
                        if (collider2D2 != collider2D1)
                        {
                            touchDir = moveDirection.normalized;
                            isTouchingWall = true;
                            rb.velocity = new Vector2(0, rb.velocity.y);
                            if (rb.velocity.y < 0)
                            {
                                rb.velocity = new Vector2(0, -wallSlideSpeed);
                                rb.gravityScale = 0;
                            }
                        }
                    }
                    else
                    {
                        isTouchingWall = false;
                    }
                }
            }
        }

    }
    void Update()
    {
        sensor.rotation = Quaternion.Euler(0, 0, Mathf.Atan2(Input.GetAxisRaw("Vertical"), Input.GetAxisRaw("Horizontal")) * Mathf.Rad2Deg);
        if (!holding)
        {
            checkSensor();
        }
        if (targetedObject != null)
        {
            reticle.gameObject.SetActive(true);
            reticle.transform.position = targetedObject.transform.position;
        }
        else
        {
            reticle.gameObject.SetActive(false);
        }
        if ((Input.GetKeyDown(KeyCode.J)) && canDash)
        {
            StartCoroutine(doDash(new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"))));
        }
        else if ((Input.GetKeyDown(KeyCode.K)) && !attackCoolDown)
        {
            if (targetedObject != null)
            {
                Debug.Log("AttackTime");
                StartCoroutine(doAttack());
            }
        }
        if (rb.velocity.y <= 0)
        {
            jumping = false;
        }
        if (isTouchingWall && (Input.GetKey(KeyCode.Z) || Input.GetKey(KeyCode.L)) && stamina > 0)
        {
            climbing = true;
        }
        else
        {
            climbing = false;
        }
        if (jumping && !Input.GetKey(KeyCode.Space) && !dashing)
        {
            jumping = false;
            rb.velocity = new Vector2(rb.velocity.x, 0);

        }
        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            jumping = true;
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            isGrounded = false;
        }
        else if (isTouchingWall && Input.GetKeyDown(KeyCode.Space))
        {
            StartCoroutine(doWallJump());
        }
        if (climbing)
        {
            if (rb.velocity.y == 0)
            {
                stamina -= Time.deltaTime * StaminaDecreasePerFrame;
            }
            else
            {
                stamina -= Time.deltaTime * StaminaDecreasePerFrame * climbMultiplyer;

            }
            Mathf.Clamp(stamina, 0, maxStamina);
        }
        if (isGrounded)
        {
            stamina = maxStamina;
        }

    }
    IEnumerator doWallJump()
    {
        wallJump = true;
        spriteRenderer.flipX = !spriteRenderer.flipX;
        rb.velocity = new Vector2(-touchDir.x * playerSpeed * Time.fixedDeltaTime * 1.5f, wallJumpForce);
        climbing = false;
        isTouchingWall = false;
        yield return new WaitForSeconds(0.25f);
        wallJump = false;
    }
    IEnumerator doUpAndOver()
    {
        upAndOver = true;
        yield return new WaitForFixedUpdate();
        yield return new WaitForFixedUpdate();
        yield return new WaitForFixedUpdate();
        rb.velocity = new Vector2(touchDir.x * playerSpeed * Time.fixedDeltaTime, 0);
        climbing = false;
        isTouchingWall = false;
        yield return new WaitForSeconds(0.15f);
        upAndOver = false;

    }
    IEnumerator manageSprites()
    {
        while (true)
        {
            if ((!isGrounded && isTouchingWall && rb.velocity.y <= 0) || climbing)
            {
                if (currSprites != climbSprites)
                {
                    currSprites = climbSprites;
                    spriteRenderer.sprite = currSprites[1];
                }
            }
            else
            {
                if (currSprites != walkSprites)
                {
                    currSprites = walkSprites;
                    spriteRenderer.sprite = currSprites[1];
                }

            }
            if (currSprites == walkSprites)
            {
                if ((!isGrounded || rb.velocity.x == 0))
                {
                    if (animateRunning)
                    {
                        animateRunning = false;
                        spriteRenderer.sprite = currSprites[1];
                        Debug.Log("walk Stop");
                    }

                }
                else
                {
                    if (!animateRunning)
                        StartCoroutine(animateSprite());
                }
            }
            else if (currSprites == climbSprites)
            {
                if (rb.velocity.y == 0 || !climbing)
                {
                    if (animateRunning)
                    {
                        animateRunning = false;
                        spriteRenderer.sprite = currSprites[1];
                        Debug.Log("climb Stop");
                    }
                }
                else
                {
                    if (!animateRunning)
                        StartCoroutine(animateSprite());
                }
            }
            yield return null;
        }
    }
    IEnumerator animateSprite()
    {
        animateRunning = true;
        while (animateRunning)
        {
            spriteRenderer.sprite = currSprites[count];
            yield return new WaitForSeconds(.125f);
            count++;
            count %= 4;
        }
    }
    void checkSensor()
    {
        List<Collider2D> results = new List<Collider2D>();
        ContactFilter2D contactFilter2D = new ContactFilter2D();
        contactFilter2D.layerMask = LayerMask.GetMask("Enemy");
        contactFilter2D.useLayerMask = true;
        Physics2D.OverlapCollider(sensor.GetComponent<EdgeCollider2D>(), contactFilter2D, results);
        Collider2D[] resultsArray = results.ToArray();
        if (resultsArray.Length > 0)
        {
            float minDistance = Vector2.Distance(transform.position, resultsArray[0].gameObject.transform.position);
            int minIndex = 0;
            for (int i = 0; i < resultsArray.Length; i++)
            {
                if (Vector2.Distance(transform.position, resultsArray[0].gameObject.transform.position) < minDistance)
                {
                    minIndex = i;
                    minDistance = Vector2.Distance(transform.position, resultsArray[0].gameObject.transform.position);
                }
            }
            if (resultsArray[minIndex].gameObject != targetedObject)
            {
                targetedObject = resultsArray[minIndex].gameObject;
            }
        }
        else
        {
            targetedObject = null;
        }
    }
    IEnumerator animateStamina()
    {
        while (true)
        {
            if (stamina <= 0)
            {
                spriteRenderer.color = Color.yellow;
            }
            else if (stamina < 60)
            {
                if (climbing)
                {
                    float roundedStamina = (int)(Mathf.CeilToInt(stamina / 20));
                    roundedStamina *= 0.1f;
                    if (spriteRenderer.color == Color.yellow)
                    {
                        spriteRenderer.color = defaultColor;
                        yield return new WaitForSeconds(roundedStamina);
                    }
                    else
                    {
                        spriteRenderer.color = Color.yellow;
                        yield return new WaitForSeconds(0.1f);
                    }

                }
                else
                {
                    spriteRenderer.color = defaultColor;
                }
            }
            else
            {
                spriteRenderer.color = defaultColor;
            }

            yield return new WaitForEndOfFrame();
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("WinObject"))
        {
            enabled = false;
            GameController.instance.doWin();
        }
    }


}